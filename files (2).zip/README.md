# OPTCG Undervalue Bot

Scans eBay, Courtyard, and Phygitals every 15 minutes.
Sends a Telegram message when a One Piece card is listed below market price.
Includes price trend (rising/falling) from PriceCharting historical data.

Cost to run: ~£4/month on Railway. Everything else is free.

---

## Step 1 — Create Your Telegram Bot (2 minutes)

1. Open Telegram → search for **@BotFather**
2. Send: `/newbot`
3. Give it a name e.g. `OPTCG Sniper` and a username e.g. `optcg_sniper_bot`
4. BotFather sends you a token like `7123456789:AAFx...` → **copy it**

### Get your Chat ID
5. Search for **@userinfobot** in Telegram
6. Send it any message → it replies with your user ID (a number like `123456789`)
7. That number is your `TELEGRAM_CHAT_ID`

> **Want alerts in a group/channel instead?**
> Add your bot to the group → send a message → visit:
> `https://api.telegram.org/bot<YOUR_TOKEN>/getUpdates`
> Find `"chat":{"id":` in the response — that's the chat ID (may be negative for groups)

---

## Step 2 — Upload to GitHub (3 minutes)

1. Go to **github.com/new** → create a **private** repo called `optcg-bot`
2. Click **uploading an existing file**
3. Drag and drop all files: `bot.py`, `scanner.py`, `watchlist.py`,
   `requirements.txt`, `railway.toml`
4. Click **Commit changes**

---

## Step 3 — Deploy on Railway (5 minutes)

1. Go to **railway.app** → sign up with GitHub (free)
2. Click **New Project → Deploy from GitHub repo** → select `optcg-bot`
3. Go to the **Variables** tab and add:

| Variable | Value |
|---|---|
| `TELEGRAM_TOKEN` | your token from Step 1 |
| `TELEGRAM_CHAT_ID` | your ID from Step 1 |
| `DISCOUNT_THRESHOLD` | `0.82` |
| `SCAN_INTERVAL_MINUTES` | `15` |

4. Click **Deploy**
5. Watch the **Logs** tab — you should see "Bot started" within 30 seconds
6. You'll get a Telegram message: "✅ OPTCG Bot Online"

Railway costs ~£4/month on the Hobby plan. Cancel anytime.

---

## Step 4 — Customise Your Watchlist

Open `watchlist.py` on GitHub (click file → pencil icon):

```python
WATCHLIST = [
    {"name": "Luffy Super Pre-Release Winner P-001", "grade": "PSA 10"},
    {"name": "Zoro Flagship Battle OP01-025", "grade": "raw"},
    # Add your own:
    {"name": "Card Name Here", "grade": "PSA 10"},
]
```

Save → Railway auto-redeploys in ~60 seconds.

---

## What Each Alert Looks Like

```
🚨 22% BELOW MARKET 🚨

🃏 Card: Zoro Flagship Battle OP01-025
📊 Grade: PSA 10
🏪 Platform: eBay

💰 Listed: £820.00
📈 Market: £1,050.00
💸 Saving: £230.00

📈 Price trend: Rising
📅 3 months ago: £890.00

📝 ONE PIECE Zoro OP01-025 Flagship PSA 10 GEM MINT
🔗 View Listing
```

---

## How Price Trend Works

The bot scrapes the historical chart from PriceCharting for each card and calculates:
- **Rising** = average price up 5%+ over last 2 months
- **Falling** = average price down 5%+ over last 2 months
- **Stable** = within 5% either way

A listing below market on a RISING card = strong buy signal.
A listing below market on a FALLING card = might be falling for a reason.

---

## Troubleshooting

**No Telegram message on startup:**
- Check Railway logs for errors
- Verify `TELEGRAM_TOKEN` and `TELEGRAM_CHAT_ID` are correct

**Bot sends "Bot started" but no deal alerts:**
- Threshold may be too tight — try `DISCOUNT_THRESHOLD=0.90`
- The card may genuinely have no undervalued listings right now

**PriceCharting returns no price:**
- The card name slug may not match their URL format
- Bot falls back to eBay sold average automatically

**Courtyard/Phygitals returning 0 results:**
- Their frontend may have changed — CSS selectors in `scanner.py` need updating
- Open the site → right-click a listing → Inspect → find class names → update selectors
